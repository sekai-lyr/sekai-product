import type { LyricData, ReplayGainInfo, SongResult, UnifiedSong } from '../types';

// src/types/onlineMusic.ts

export type MediaId = string | number;
export type OnlineProviderId = 'netease' | (string & {});
export type AudioQualityPreference = 'standard' | 'high' | 'lossless' | 'hires';
export type ProviderCatalogEntityKind = 'album' | 'artist' | 'playlist';

export interface ProviderCatalogRef {
    providerId: OnlineProviderId;
    kind: ProviderCatalogEntityKind;
    id: MediaId;
}

export type JsonPrimitive = string | number | boolean | null;
export type JsonValue = JsonPrimitive | JsonValue[] | { [key: string]: JsonValue };

export type PlaybackSourceRef =
    | {
        kind: 'online';
        providerId: OnlineProviderId;
        mediaId: string;
        variant?: string;
        providerData?: Record<string, JsonValue>;
    }
    | { kind: 'local'; mediaId: string }
    | { kind: 'navidrome'; mediaId: string }
    | { kind: 'stage'; mediaId: string };

export interface ProviderCapabilities {
    search: boolean;
    playback: boolean;
    lyrics: boolean;
    auth: boolean;
    userLibrary: boolean;
    playlists: boolean;
    albums: boolean;
    artists: boolean;
    recommendations: boolean;
    mutations: boolean;
    /** Personal FM can be steered by mode/scene, i.e. `getPersonalFm` honours PersonalFmRequestOptions. */
    personalFmModes?: boolean;
    wordByWordLyrics: boolean;
    userCloud?: boolean;
    historyRecommendations?: boolean;
    playlistSubscription?: boolean;
    playlistTrackMutations?: boolean;
    likes?: boolean;
    userAlbums?: boolean;
    /** The provider accepts a listening report for a track the user actually played. */
    playbackReports?: boolean;
}

export interface ProviderAvailability {
    configured: boolean;
    reason?: 'not-configured' | 'runtime-unavailable';
}

export interface ProviderAccountSummary {
    providerId: OnlineProviderId;
    displayName: string;
    shortName: string;
    availability: ProviderAvailability;
    /** False for a provider with no account at all (a Folium mod source): it is used without signing in. Absent means true. */
    requiresAccount?: boolean;
    status: 'unknown' | 'authenticated' | 'anonymous' | 'error';
    user: ProviderUser | null;
    collections: ProviderCollection[];
    error?: string;
    hydration?: 'loading' | 'ready';
    freshness?: 'stale' | 'refreshing' | 'fresh' | 'error';
    lastUpdatedAt?: number;
}

export interface ProviderPage<T> {
    items: T[];
    total?: number;
    hasMore: boolean;
    nextOffset: number;
}

export interface ProviderAudioSource {
    url: string;
    fetchedAt: number;
    expiresAt?: number;
    quality: AudioQualityPreference;
    replayGain?: ReplayGainInfo;
}

export type ProviderSongAvailabilityState = 'playable' | 'unavailable' | 'unknown';

export interface ProviderSongAvailability {
    state: ProviderSongAvailabilityState;
    label?: string;
}

export interface ProviderSongReplacement {
    song: UnifiedSong;
    label?: string;
}

export interface ChorusRange {
    startTime: number;
    endTime: number;
}

export interface ProviderLyricsResult {
    lyrics: LyricData | null;
    mainText?: string | null;
    wordByWordText?: string | null;
    translationText?: string | null;
    romanizationText?: string | null;
    isPureMusic: boolean;
    chorusRanges?: ChorusRange[];
}

export interface ProviderAlbumSummary {
    id: MediaId;
    name: string;
    coverUrl?: string;
    entityId?: string;
    catalogRef?: ProviderCatalogRef;
}

export interface ProviderSongMetadata {
    artists: ProviderArtistSummary[];
    album: ProviderAlbumSummary;
    durationMs: number;
    coverUrl?: string;
    aliases: string[];
    translatedNames: string[];
}

export interface ProviderUser {
    id: MediaId;
    nickname: string;
    avatarUrl?: string;
    backgroundUrl?: string;
    vipType?: number;
}

export interface ProviderArtistSummary {
    id: MediaId;
    name: string;
    entityId?: string;
    catalogRef?: ProviderCatalogRef;
}

export interface ProviderHistoryEntry {
    id: string;
    label: string;
    providerData?: Record<string, JsonValue>;
}

export interface ProviderCollection {
    providerId: OnlineProviderId;
    id: MediaId;
    name: string;
    type: 'playlist' | 'album' | 'artist' | 'radio' | 'cloud' | string;
    coverUrl?: string;
    description?: string;
    trackCount?: number;
    albumCount?: number;
    isOwned?: boolean;
    creator?: ProviderUser;
    artists?: ProviderArtistSummary[];
    aliases?: string[];
    publishedAt?: number;
    publisher?: string;
    playCount?: number;
    updatedAt?: number;
    tracksUpdatedAt?: number;
    isLiked?: boolean;
    providerData?: Record<string, JsonValue>;
}

export type QrLoginState =
    | { state: 'waiting' }
    | { state: 'scanned' }
    | { state: 'confirmed' }
    | { state: 'expired' }
    | {
        state: 'error';
        message?: string;
        /** 结构化的失败原因；provider 能确定时才给（例如用户在手机上取消了登录）。 */
        reason?: QrLoginErrorReason;
        /** 后端要求的冷却时长：这段时间内重新要码只会被拒（429），界面应先等它结束。 */
        retryAfterMs?: number;
        /**
         * 这次轮询在网络层失败（没拿到上游的回应，例如连接被重置）：二维码在服务端仍然有效，
         * 会话会接着轮询，连续失败超过上限才算登录失败。
         */
        transient?: boolean;
        /** 后端返回的原始字段（返回码、失败阶段与原因等），原样进诊断时间线。 */
        detail?: Record<string, unknown>;
    };

/**
 * 扫码失败的结构化原因：「在手机上取消」是用户自己的操作，不需要诊断入口；「连接被重置」是轮询请求被
 * 上游直接断开，同一网络出口和设备标识下反复重试多半无效，界面要提示换网络或重启应用。
 */
export type QrLoginErrorReason = 'canceled-on-device' | 'connection-reset';

// 扫码登录失败的几种形态，决定登录弹窗要不要给出「复制诊断信息」入口。
// 没扫码就过期属于正常情况，不算失败；扫过码却过期，多半是手机端确认被拒。
export type QrLoginFailureKind =
    | 'start-error'
    | 'check-error'
    | 'expired-after-scan'
    | 'account-refresh-failed'
    // 用户在手机上取消了这次登录：照常可以重试（可能要先等冷却），不给诊断入口。
    | 'canceled-on-device'
    // 轮询请求被上游断开（ECONNRESET）：照常给诊断入口，状态行提示换网络或重启应用。
    | 'connection-reset';

export type ProviderErrorCode =
    | 'auth-required'
    | 'unsupported'
    // 集合设为不公开，当前这条读取路径没资格读它。与 `unsupported`（这个后端或 provider 没有这项能力）
    // 分开，界面才能只在这种情况下给出「不是公开歌单」的解释。
    | 'not-public'
    | 'unavailable'
    | 'not-playable'
    | 'preview-only'
    | 'region-restricted'
    | 'network'
    | 'invalid-response';

export class OnlineProviderError extends Error {
    constructor(
        public readonly code: ProviderErrorCode,
        message: string,
        public readonly providerId?: OnlineProviderId,
        public readonly cause?: unknown,
        /** 非 2xx 响应的 HTTP 状态，与响应体里的 code 分开；只有按 HTTP 状态分流的 transport 会传。 */
        public readonly httpStatus?: number,
        /** 后端要求的冷却时长（429 退避）；只有能读出它的 transport 会传。 */
        public readonly retryAfterMs?: number,
    ) {
        super(message);
        this.name = 'OnlineProviderError';
    }
}

export interface OnlineSearchProvider {
    searchSongs(query: string, limit: number, offset: number): Promise<ProviderPage<UnifiedSong>>;
}

export interface OnlinePlaybackProvider {
    getSongDetail(id: MediaId): Promise<UnifiedSong | null>;
    getAudioSource(song: SongResult, quality: AudioQualityPreference): Promise<ProviderAudioSource | null>;
    getAvailability?(song: SongResult): ProviderSongAvailability;
    getReplacement?(song: SongResult): Promise<ProviderSongReplacement | null>;
}

/**
 * One finished listening report, in the only two units a provider can be told the truth in:
 * how many seconds of this track were really rendered, and how long the track is.
 *
 * `playedSeconds` is never a position on the progress bar - a listener who drags to the end has
 * not listened to the song. Callers must hand over accumulated playback and must already have
 * capped it at `totalSeconds`; nothing downstream can tell an inflated number from a real one.
 */
export interface ProviderPlaybackReport {
    playedSeconds: number;
    totalSeconds?: number;
    quality?: AudioQualityPreference;
}

export interface OnlinePlaybackReportProvider {
    reportPlayback(song: SongResult, report: ProviderPlaybackReport): Promise<void>;
}

export interface OnlineLyricsProvider {
    getLyrics(song: SongResult, context?: { userId?: MediaId | null }): Promise<ProviderLyricsResult>;
    getChorusRanges?(songId: MediaId): Promise<ChorusRange[]>;
}

export interface OnlineSongMetadataProvider {
    getSongMetadata(song: SongResult): ProviderSongMetadata;
}

// provider 自行声明它支持哪几种扫码登录方式；不声明即代表只有单一方式，UI 维持单步流程。
export interface QrLoginMethod {
    id: string;          // 传给后端的识别值（QQ: 'qq' | 'wechat'）
    labelKey: string;    // i18n key，由 UI 层翻译
    iconKey: string;     // 图标识别值，由 UI 层映射到静态资源
}

/** 自检里一项失败的原因：Node 错误码（没有时为 null）、原文、断在哪一步。 */
export type LoginSelfCheckError = {
    code: string | null;
    message: string;
    phase?: 'dns' | 'tcp' | 'tls' | 'http';
};

export type LoginSelfCheckAddress = { address: string; family: 4 | 6 };

/** 对一个上游域名的检查：DNS → 分协议族的 TCP + TLS 握手 → 一次真实的 HTTPS 请求。 */
export type LoginSelfCheckHost = {
    host: string;
    dns: {
        addresses: LoginSelfCheckAddress[];
        durationMs: number;
        error: LoginSelfCheckError | null;
        /** DNS 返回了 198.18.0.0/15（TUN 模式代理的 fake-ip）。 */
        fakeIp: boolean;
    };
    connections: Array<LoginSelfCheckAddress & {
        tcpMs: number | null;
        tlsMs: number | null;
        error: LoginSelfCheckError | null;
        protocol?: string | null;
    }>;
    https: {
        httpStatus: number | null;
        durationMs: number;
        remote: LoginSelfCheckAddress | null;
        error: LoginSelfCheckError | null;
        /** 本机时间减服务器 Date 头的时间（毫秒）；拿不到时为 null。 */
        clockSkewMs: number | null;
    } | null;
};

/**
 * 扫码登录失败后的主动自检结果。桌面版由主进程检查本地后端、代理、DNS、TCP / TLS 与 HTTPS；
 * 网页版只能检查配置的远端 API 能不能连上（hosts 为空、proxy 为 null）。
 */
export type LoginSelfCheckResult = {
    providerId: OnlineProviderId;
    runtime: 'electron' | 'web';
    startedAt: number;
    durationMs: number;
    backend: {
        /** 桌面版是内嵌后端的状态（running / starting / error / unavailable）；网页版固定为 remote。 */
        status: string;
        port: number | null;
        error: string | null;
        /** 对后端发的一次 HTTP 请求；后端不在运行时为 null。 */
        probe: { ok: boolean; httpStatus: number | null; durationMs: number; error: LoginSelfCheckError | null } | null;
        /** 网页版检查的远端 API 地址。 */
        url?: string;
    } | null;
    proxy: { env: Record<string, string>; system: string | null } | null;
    hosts: LoginSelfCheckHost[];
    /** 桌面版的凭据加密后端（safeStorage）；Linux 上为 basic_text 时 QQ 的登录态无法保存。网页版没有。 */
    credentialStore?: { encryptionAvailable?: boolean; backend?: string | null; error?: string } | null;
};

export interface OnlineAuthProvider {
    getLoginStatus(): Promise<ProviderUser | null>;
    logout(): Promise<void>;
    getQrLoginMethods?(): QrLoginMethod[];
    // 需要远端能力发现的 provider 在这里等待结果；UI 用同一份返回值决定单步或多步流程。
    resolveQrLoginMethods?(): Promise<QrLoginMethod[]>;
    getQrKey?(methodId?: string): Promise<string>;
    createQr?(key: string): Promise<string>;
    checkQr?(key: string): Promise<QrLoginState>;
    // 只释放这一把 key 的会话，实现必须是幂等的：调用方在关窗时 fire-and-forget，
    // 未知或已过期的 key 也算成功。没有会话概念的 provider 不必实现。
    cancelQr?(key: string): Promise<void>;
    // 二维码的有效期。声明了它，UI 才会自己计时并在到点时停止轮询、给出重试；
    // 不声明就沿用原本的做法——只认后端报出的过期状态。
    getQrTtlMs?(): number;
    // 扫码登录失败后附进诊断报告的 provider 专属信息，每项一行、已格式化好（后端状态、拉起步骤、请求与连接记录等）。
    // 报告会贴进公开的 issue，界面已告知用户其中包含哪些数据；登录凭据（cookie、token、session）的值不能出现。
    getQrLoginDiagnostics?(): Promise<string[]>;
    // 主动自检：扫码登录失败后由会话调用一次，结果进诊断报告，结论显示在登录界面上。
    // canRunQrLoginSelfCheck 同步回答此刻能不能检查（界面据此决定要不要显示「正在检查」）。
    canRunQrLoginSelfCheck?(): boolean;
    runQrLoginSelfCheck?(): Promise<LoginSelfCheckResult | null>;
}

export interface OnlineLibraryProvider {
    getUserPlaylists(userId: MediaId, limit: number, offset: number): Promise<ProviderPage<ProviderCollection>>;
    getLikedSongIds?(userId: MediaId): Promise<MediaId[]>;
    /** Full liked-track records, used when a provider needs more than the song id (e.g. KuGou fileId). */
    getLikedSongs?(userId: MediaId): Promise<UnifiedSong[]>;
    getUserAlbums?(userId: MediaId, limit: number, offset: number): Promise<ProviderPage<ProviderCollection>>;
    getCloudCollection?(user?: ProviderUser): Promise<ProviderCollection | null>;
}

export interface OnlineCatalogProvider {
    canResolveSongCatalogRefs?(song: UnifiedSong): boolean;
    resolveSongCatalogRefs?(song: UnifiedSong): Promise<UnifiedSong>;
    getPlaylistTracks?(id: MediaId, limit: number, offset: number, collection?: ProviderCollection): Promise<ProviderPage<UnifiedSong>>;
    getPlaylistDetail?(id: MediaId, collection?: ProviderCollection): Promise<ProviderCollection | null>;
    getCloudTracks?(limit: number, offset: number, collection?: ProviderCollection): Promise<ProviderPage<UnifiedSong>>;
    getAlbumTracks?(id: MediaId, limit?: number, offset?: number, collection?: ProviderCollection): Promise<ProviderPage<UnifiedSong>>;
    getAlbumDetail?(id: MediaId, collection?: ProviderCollection): Promise<ProviderCollection | null>;
    getArtistSongs?(id: MediaId, limit: number, offset: number): Promise<ProviderPage<UnifiedSong>>;
    getArtistAlbums?(id: MediaId, limit: number, offset: number): Promise<ProviderPage<ProviderCollection>>;
    getArtistDetail?(id: MediaId): Promise<ProviderCollection | null>;
    getSubscriptionStatus?(type: 'playlist' | 'album', id: MediaId, collection?: ProviderCollection): Promise<boolean>;
}

/**
 * Personal FM tuning, provider-neutral on purpose: only NetEase's `/personal/fm/mode` understands
 * these, and a provider without the concept ignores them rather than failing the call.
 */
export interface PersonalFmRequestOptions {
    mode?: string;
    submode?: string | null;
}

export interface OnlineRecommendationProvider {
    getDailySongs?(refresh?: boolean): Promise<UnifiedSong[]>;
    getPersonalFm?(options?: PersonalFmRequestOptions): Promise<UnifiedSong[]>;
    getRecommendedCollections?(limit: number): Promise<ProviderCollection[]>;
    getHistoryEntries?(): Promise<ProviderHistoryEntry[]>;
    getHistoryDates?(): Promise<string[]>;
    getHistorySongs?(entry: ProviderHistoryEntry | string): Promise<UnifiedSong[]>;
    dislikeSong?(id: MediaId): Promise<{ replacement?: UnifiedSong; limitReached?: boolean }>;
}

export interface OnlineMutationProvider {
    canAddToPlaylist?(playlist: ProviderCollection): boolean;
    likeSong?(
        song: MediaId | SongResult,
        liked: boolean,
        context?: { likedFileId?: MediaId },
    ): Promise<void>;
    updatePlaylistTracks?(
        operation: 'add' | 'del',
        playlist: MediaId | ProviderCollection,
        tracks: Array<MediaId | SongResult>,
    ): Promise<void>;
    subscribePlaylist?(playlist: MediaId | ProviderCollection, subscribed: boolean): Promise<void>;
    subscribeAlbum?(id: MediaId, subscribed: boolean): Promise<void>;
}

export interface OnlineMusicProvider {
    id: OnlineProviderId;
    displayName: string;
    shortName?: string;
    getAvailability?(): ProviderAvailability;
    capabilities: ProviderCapabilities;
    normalizeSong(raw: unknown): UnifiedSong;
    normalizeUser?(raw: unknown): ProviderUser;
    normalizeCollection?(raw: unknown, type?: string): ProviderCollection;
    songMetadata?: OnlineSongMetadataProvider;
    getSongPageUrl?(song: SongResult): string | null;
    search?: OnlineSearchProvider;
    playback?: OnlinePlaybackProvider;
    playbackReports?: OnlinePlaybackReportProvider;
    lyrics?: OnlineLyricsProvider;
    auth?: OnlineAuthProvider;
    library?: OnlineLibraryProvider;
    catalog?: OnlineCatalogProvider;
    recommendations?: OnlineRecommendationProvider;
    mutations?: OnlineMutationProvider;
}

// Public canonical contract consumed through the omni facade. Provider-prefixed
// names above remain internal adapter vocabulary while the migration completes.
export type OmniProviderId = OnlineProviderId;
export type OmniMediaId = MediaId;
export type OmniProviderCapabilities = ProviderCapabilities;
export type OmniProviderAvailability = ProviderAvailability;
export type OmniProviderSummary = ProviderAccountSummary;
export type OmniAccountState = ProviderAccountSummary;
export type OmniPage<T> = ProviderPage<T>;
export type OmniAudioSource = ProviderAudioSource;
export type OmniSongAvailability = ProviderSongAvailability;
export type OmniSongReplacement = ProviderSongReplacement;
export type OmniLyricsResult = ProviderLyricsResult;
export type OmniPlaybackReport = ProviderPlaybackReport;
export type OmniChorusRange = ChorusRange;
export type OmniAlbum = ProviderAlbumSummary;
export type OmniArtist = ProviderArtistSummary;
export type OmniUser = ProviderUser;
export type OmniCollection = ProviderCollection;
export type OmniHistoryEntry = ProviderHistoryEntry;
export { OnlineProviderError as OmniError };
