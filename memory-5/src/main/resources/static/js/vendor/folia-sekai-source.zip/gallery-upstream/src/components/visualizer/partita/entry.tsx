import React from 'react';
import { defineVisualizer } from '../definition';
import { PartitaSettingsPanel } from '../settingsPanels';

const VisualizerPartita = React.lazy(() => import('./VisualizerPartita'));

// src/components/visualizer/partita/entry.tsx
// Registers Partita and its preview tuning panel.
export default defineVisualizer({
    mode: 'partita',
    order: 50,
    labelKey: 'ui.visualizerPartita',
    labelFallback: '云阶',
    previewSeed: 'partita',
    previewStartOffset: 0,
    tuningKind: 'partita',
    usesWordSegmentation: true,
    render: props => <VisualizerPartita {...props} />,
    renderSettingsPanel: props => <PartitaSettingsPanel {...props} />,
    resetSettings: ({ resetPartitaTuning }) => {
        resetPartitaTuning?.();
    },
});
